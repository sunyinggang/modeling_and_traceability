from app import app

if __name__ == '__main__':
    app.run(debug=True, port=16009, host='0.0.0.0')
